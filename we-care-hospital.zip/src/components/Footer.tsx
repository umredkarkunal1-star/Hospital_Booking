import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Heart,
  Mail,
  Phone,
  MapPin
} from 'lucide-react';

export const Footer: React.FC = () => {
  const navigate = useNavigate();

  const handleAnchorLink = (sectionId: string) => {
    navigate('/#' + sectionId);
    setTimeout(() => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <footer className="bg-gray-900 text-gray-300 border-t border-gray-800 font-sans">
      
      {/* 4-column Upper footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Column 1: Hospital logo + tagline + social links (lg:col-span-4) */}
          <div className="lg:col-span-4 space-y-6">
            <Link to="/" className="flex items-center gap-2" aria-label="We Care Hospital Home">
              <div className="bg-blue-600 text-white p-2 rounded-xl">
                <Heart className="w-5 h-5 fill-current" />
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">
                We Care <span className="text-blue-500">Hospital</span>
              </span>
            </Link>
            <p className="text-sm text-gray-400 leading-relaxed max-w-sm">
              We Care Hospital has delivered superior, patient-centered medical treatment across generations. Combining advanced technologies with direct clinical empathy.
            </p>
            {/* Social Links */}
            <div className="flex items-center gap-3">
              <a 
                href="#" 
                onClick={(e) => e.preventDefault()}
                className="p-2 bg-gray-800 hover:bg-blue-650 hover:text-white rounded-lg transition-all duration-200" 
                aria-label="Follow We Care Hospital on Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                onClick={(e) => e.preventDefault()}
                className="p-2 bg-gray-800 hover:bg-blue-650 hover:text-white rounded-lg transition-all duration-200" 
                aria-label="Follow We Care Hospital on Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                onClick={(e) => e.preventDefault()}
                className="p-2 bg-gray-800 hover:bg-blue-650 hover:text-white rounded-lg transition-all duration-200" 
                aria-label="Follow We Care Hospital on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                onClick={(e) => e.preventDefault()}
                className="p-2 bg-gray-800 hover:bg-blue-650 hover:text-white rounded-lg transition-all duration-200" 
                aria-label="Follow We Care Hospital on LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links (lg:col-span-2) */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/" className="hover:text-blue-500 transition-colors">Home</Link>
              </li>
              <li>
                <button onClick={() => handleAnchorLink('about')} className="hover:text-blue-500 transition-colors cursor-pointer text-left">About Us</button>
              </li>
              <li>
                <Link to="/departments" className="hover:text-blue-500 transition-colors">Departments</Link>
              </li>
              <li>
                <Link to="/doctors" className="hover:text-blue-500 transition-colors">Doctors</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-blue-500 transition-colors">Services</Link>
              </li>
              <li>
                <button onClick={() => handleAnchorLink('blog')} className="hover:text-blue-500 transition-colors cursor-pointer text-left">Health Blog</button>
              </li>
              <li>
                <Link to="/contact" className="hover:text-blue-500 transition-colors">Contact</Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Departments Listed (lg:col-span-3) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Key Specialities</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/doctors/cardiology" className="hover:text-blue-500 transition-colors">Cardiology Departments</Link>
              </li>
              <li>
                <Link to="/doctors/neurology" className="hover:text-blue-500 transition-colors">Neurology Ward</Link>
              </li>
              <li>
                <Link to="/doctors/orthopedics" className="hover:text-blue-500 transition-colors">Orthopedics Specialists</Link>
              </li>
              <li>
                <Link to="/doctors/pediatrics" className="hover:text-blue-500 transition-colors">Pediatrics Clinic</Link>
              </li>
              <li>
                <Link to="/doctors/oncology" className="hover:text-blue-500 transition-colors">Oncology Diagnostic</Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact info (lg:col-span-3) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Contact Info</h4>
            <ul className="space-y-3.5 text-sm">
              <li className="flex gap-2.5">
                <MapPin className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                <span className="text-gray-400">
                  123 Health Avenue, Solapur, Maharashtra, India
                </span>
              </li>
              <li className="flex gap-2.5">
                <Phone className="w-5 h-5 text-blue-500 shrink-0" />
                <span className="text-gray-400 font-mono">
                  +91-800-WE-CARE
                </span>
              </li>
              <li className="flex gap-2.5">
                <Mail className="w-5 h-5 text-blue-500 shrink-0" />
                <span className="text-gray-400 font-mono">
                  contact@wecarehospital.in
                </span>
              </li>
            </ul>
          </div>

        </div>
      </div>

      {/* Bottom bar */}
      <div className="bg-gray-950 text-gray-500 py-6 border-t border-gray-800/60 text-xs text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-3">
          <span>
            © 2025 We Care Hospital. All Rights Reserved.
          </span>
          <div className="flex gap-4 font-medium">
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-gray-350 transition-colors">Privacy Policy</a>
            <span className="text-gray-800">|</span>
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-gray-350 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>

    </footer>
  );
};
