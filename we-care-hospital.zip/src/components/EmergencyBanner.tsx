import React from 'react';
import { MedicalIcon } from './MedicalIcon';

export const EmergencyBanner: React.FC = () => {
  const handleCallEmergency = () => {
    // Standard phone trigger action
    window.location.href = 'tel:+91800932273';
  };

  return (
    <div 
      id="emergency-beacon-banner" 
      className="bg-red-600 text-white w-full py-3.5 px-4 shadow-md flex items-center justify-center relative overflow-hidden z-45"
      role="alert"
    >
      {/* Visual pulsing background texture */}
      <div className="absolute inset-0 bg-red-700/20 opacity-30 animate-pulse pointer-events-none"></div>

      <div className="max-w-7xl w-full mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-center md:text-left z-10 px-4">
        
        <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-2.5">
          <span className="flex h-3.5 w-3.5 rounded-full bg-white relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-80"></span>
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-red-100 items-center justify-center text-red-650 font-bold text-[9px]">🚨</span>
          </span>
          <span className="font-sans font-extrabold text-sm sm:text-base tracking-tight">
            24/7 Trauma Emergency? Call Now:{' '}
            <a 
              href="tel:+91800932273" 
              className="underline font-mono tracking-wider hover:text-red-100 transition-colors"
            >
              +91-800-WE-CARE
            </a>
          </span>
        </div>

        <button
          id="direct-call-emergency-btn"
          onClick={handleCallEmergency}
          className="bg-white hover:bg-red-50 text-red-600 font-bold text-xs px-5 py-2 rounded-full shadow-sm transition-all duration-200 transform hover:scale-103 inline-flex items-center gap-1.5 cursor-pointer uppercase shrink-0"
        >
          <MedicalIcon name="Phone" className="w-3.5 h-3.5 text-red-600 animate-bounce" />
          Call Emergency
        </button>

      </div>
    </div>
  );
};
