import React from 'react';
import { Link } from 'react-router-dom';
import { MedicalIcon } from './MedicalIcon';

export const Hero: React.FC = () => {
  return (
    <section id="hero-section" className="relative w-full overflow-hidden bg-gradient-to-r from-blue-50 to-white pt-12 pb-20 lg:pt-20 lg:pb-28">
      
      {/* Abstract Medical Graphic based on Sleek Interface theme */}
      <div className="absolute right-0 top-0 h-full w-1/3 opacity-10 pointer-events-none select-none">
        <svg className="h-full w-full" viewBox="0 0 200 200">
          <circle cx="100" cy="100" r="80" fill="#1A73E8" />
          <rect x="90" y="40" width="20" height="120" fill="white" />
          <rect x="40" y="90" width="120" height="20" fill="white" />
        </svg>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Hero text */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-block px-4 py-1.5 bg-white rounded-full text-blue-600 text-xs font-bold uppercase tracking-wider mb-4 border border-blue-100 shadow-sm">
              ✨ Excellence in Healthcare
            </div>
            
            <h1 className="font-sans font-extrabold text-4xl sm:text-5xl lg:text-6xl tracking-tight text-blue-700 leading-[1.1] mb-4">
              Compassionate Care. <br />
              <span className="text-blue-600">Advanced Medicine.</span>
            </h1>
            
            <p className="font-sans text-gray-500 text-lg sm:text-xl max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Serving patients with excellence across all specialties. Your health is our priority, backed by world-class technology and expert physicians.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <Link
                id="hero-book-cta"
                to="/book-appointment"
                className="w-full sm:w-auto text-center bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-4 rounded-xl shadow-lg shadow-blue-200 transition-all duration-200 transform hover:-translate-y-0.5"
              >
                Start Consultation
              </Link>
              <Link
                id="hero-explore-cta"
                to="/departments"
                className="w-full sm:w-auto text-center bg-white border border-[#1A73E8] text-[#1A73E8] font-bold px-8 py-4 rounded-xl shadow-sm hover:bg-blue-50/50 transition-all duration-200"
              >
                Explore Departments
              </Link>
            </div>
          </div>

          {/* Hero Image Illustration Placeholder */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-md aspect-square rounded-3xl bg-blue-50 border-4 border-white shadow-xl/10 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-blue-600/5 mix-blend-multiply"></div>
              {/* Symbolic illustration */}
              <div className="p-8 text-center flex flex-col items-center">
                <div className="p-4 bg-white rounded-2xl shadow-md text-blue-600 mb-4 animate-bounce">
                  <MedicalIcon name="HeartPulse" className="w-12 h-12" />
                </div>
                <h3 className="font-sans font-bold text-gray-800 text-lg">We Care Medical Plaza</h3>
                <p className="text-xs text-gray-400 font-mono mt-1">ESTD. 1998 • SOLAPUR</p>
                <div className="mt-6 flex flex-col gap-2 w-full max-w-xs text-left bg-white/90 backdrop-blur-sm p-4 rounded-xl border border-blue-50 shadow-sm text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500"></span>
                    <span className="font-medium text-gray-700">ICU Bed Availability: Stable</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    <span className="font-medium text-gray-700">ER response time: &lt; 8 Mins</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                    <span className="font-medium text-gray-700">OPD Intake: Fully operational</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Floating Stats Bar */}
        <div className="mt-16 bg-white border border-blue-50 rounded-2xl shadow-sm py-6 px-4 max-w-6xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-2 items-center text-center">
            
            <div className="flex flex-col items-center py-2">
              <span className="text-3xl font-extrabold text-blue-600">25+</span>
              <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500 mt-1">Departments</span>
            </div>
            
            <div className="flex flex-col items-center py-2 border-l border-blue-50">
              <span className="text-3xl font-extrabold text-blue-600">100+</span>
              <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500 mt-1">Doctors</span>
            </div>
            
            <div className="flex flex-col items-center py-2 border-l border-blue-50">
              <span className="text-3xl font-extrabold text-blue-600">50k+</span>
              <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500 mt-1">Patients Treated</span>
            </div>
            
            <div className="flex flex-col items-center py-2 border-l border-blue-50">
              <span className="text-3xl font-extrabold text-[#00ACC1]">24/7</span>
              <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500 mt-1">Emergency Care</span>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
