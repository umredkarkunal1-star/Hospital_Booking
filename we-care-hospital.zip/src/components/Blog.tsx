import React from 'react';
import { blogPosts } from '../data/blog';
import { MedicalIcon } from './MedicalIcon';

export const Blog: React.FC = () => {
  return (
    <section id="blog" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            Health Tips & Medical News
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            Stay up to date with the newest diagnostic standards and heart-healthy lifestyle tips drafted directly by our department advisors.
          </p>
        </div>

        {/* 3 columns blog posts */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article 
              key={post.id} 
              className="bg-white rounded-3xl border border-gray-100/80 shadow-xs hover:shadow-lg hover:border-blue-100 transition-all duration-300 overflow-hidden flex flex-col justify-between group"
            >
              <div>
                {/* Blue-tinted Thumbnail Placeholder */}
                <div className="relative w-full aspect-16/9 bg-blue-50/70 py-10 flex items-center justify-center border-b border-gray-55 overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-100/50 rounded-full blur-xl translate-x-8 -translate-y-8"></div>
                  <div className="p-4 bg-white text-blue-600 rounded-2xl shadow-sm z-10 group-hover:scale-105 transition-transform duration-300">
                    <MedicalIcon name="BookOpen" className="w-8 h-8" />
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-6 space-y-3">
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="font-bold uppercase text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full">
                      {post.category}
                    </span>
                    <span className="text-gray-400 font-semibold">{post.date}</span>
                  </div>

                  <h3 className="font-sans font-bold text-gray-950 text-base md:text-lg group-hover:text-blue-600 transition-colors duration-200 line-clamp-2">
                    {post.title}
                  </h3>

                  <p className="text-sm text-gray-550 leading-relaxed line-clamp-2" title={post.excerpt}>
                    {post.excerpt}
                  </p>
                </div>
              </div>

              {/* Footer read more CTA */}
              <div className="p-6 pt-0 mt-auto border-t border-gray-50/50">
                <a 
                  id={`blog-read-btn-${post.id}`}
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="inline-flex items-center gap-1 text-sm font-bold text-blue-600 hover:text-blue-700 hover:underline pt-4 w-fit"
                >
                  Read More
                  <MedicalIcon name="ArrowRight" className="w-4 h-4" />
                </a>
              </div>

            </article>
          ))}
        </div>

      </div>
    </section>
  );
};
