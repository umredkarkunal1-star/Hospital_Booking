import React from 'react';
import {
  Heart,
  Brain,
  Activity,
  Baby,
  Shield,
  Sparkles,
  Users,
  Eye,
  Volume2,
  Database,
  Wind,
  Flame,
  Smile,
  Sun,
  Ambulance,
  ShieldAlert,
  ClipboardList,
  HeartPulse,
  CheckSquare,
  Video,
  Pill,
  Accessibility,
  Droplet,
  Syringe,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  Clock,
  Star,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  User,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Award,
  BookOpen
} from 'lucide-react';

// Dictionary mapping icon names to their respective React Lucide component
const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Heart,
  Brain,
  Activity,
  Baby,
  Shield,
  Sparkles,
  Users,
  Eye,
  Volume2,
  Database,
  Wind,
  Flame,
  Smile,
  Sun,
  Ambulance,
  ShieldAlert,
  ClipboardList,
  HeartPulse,
  CheckSquare,
  Video,
  Pill,
  Accessibility,
  Droplet,
  Syringe,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  Clock,
  Star,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  User,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Award,
  BookOpen
};

interface MedicalIconProps {
  name: string;
  className?: string;
}

export const MedicalIcon: React.FC<MedicalIconProps> = ({ name, className }) => {
  const IconComponent = iconMap[name];
  if (!IconComponent) {
    // Default fallback icon
    return <Activity className={className} />;
  }
  return <IconComponent className={className} />;
};
