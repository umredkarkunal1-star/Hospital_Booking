import React, { useState } from 'react';
import { MedicalIcon } from './MedicalIcon';

export const Contact: React.FC = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (error) setError(null);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setError('All contact fields are strictly required.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email)) {
      setError('Please provide a valid email structure.');
      return;
    }

    setIsSubmitting(true);

    // Simulate database dispatch delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setForm({ name: '', email: '', message: '' });
    }, 1000);
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            Connect With Our Reception Services
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            Reach out with administrative queries, medical reporting questions, or general healthcare inquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Contact Form */}
          <div className="lg:col-span-6 bg-gray-50/50 border border-gray-100 rounded-3xl p-6 sm:p-10 relative">
            <h3 className="font-sans font-bold text-gray-900 text-xl mb-6">Send an Inquiry Message</h3>
            
            {isSuccess ? (
              <div id="contact-success-panel" className="bg-green-50 border border-green-100 text-green-800 rounded-2xl p-6 text-center space-y-4 animate-in zoom-in-95">
                <div className="mx-auto bg-green-100 text-green-650 p-2.5 rounded-full w-fit">
                  <MedicalIcon name="CheckCircle" className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="font-bold text-base">Inquiry Submitted!</h4>
                  <p className="text-xs text-green-700 mt-1 leading-relaxed">
                    Thank you. Your message has been received. Our administrative reception desk typically responses within 1-2 clinical hours.
                  </p>
                </div>
                <button
                  id="contact-refresh-btn"
                  onClick={() => setIsSuccess(false)}
                  className="bg-white border border-green-200 text-green-800 text-xs font-bold px-4 py-2 rounded-xl"
                >
                  Write Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                {error && (
                  <div className="p-3 bg-red-50 border border-red-150 text-red-600 text-xs font-semibold rounded-xl flex items-center gap-2">
                    <MedicalIcon name="AlertTriangle" className="w-4 h-4 text-red-650" />
                    <span>{error}</span>
                  </div>
                )}

                <div>
                  <label htmlFor="contact_name" className="block text-sm font-semibold text-gray-750 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    id="contact_name"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    className="w-full border border-gray-200 focus:border-blue-500 rounded-xl px-4 py-2.5 outline-none bg-white text-sm"
                    placeholder="Enter full name"
                    disabled={isSubmitting}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="contact_email" className="block text-sm font-semibold text-gray-755 mb-1.5">Email Address</label>
                  <input
                    type="email"
                    id="contact_email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    className="w-full border border-gray-200 focus:border-blue-500 rounded-xl px-4 py-2.5 outline-none bg-white text-sm"
                    placeholder="user@example.com"
                    disabled={isSubmitting}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="contact_message" className="block text-sm font-semibold text-gray-750 mb-1.5">Your Medical Message / Inquiry</label>
                  <textarea
                    id="contact_message"
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    rows={5}
                    className="w-full border border-gray-200 focus:border-blue-500 rounded-xl px-4 py-2.5 outline-none bg-white text-sm resize-none"
                    placeholder="State the nature of your clinical question, patient report inquiries, or logistics..."
                    disabled={isSubmitting}
                    required
                  ></textarea>
                </div>

                <button
                  id="contact-submit-btn"
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200 transition-all duration-200 cursor-pointer text-sm"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Sending Message...' : 'Submit Inquiry'}
                </button>
              </form>
            )}
          </div>

          {/* Right Column: Contact Details + Embed Map */}
          <div className="lg:col-span-6 space-y-10">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Address details */}
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                    <MedicalIcon name="MapPin" className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-gray-950 text-base">Hospital Address</h4>
                    <p className="text-sm text-gray-650 leading-relaxed mt-1">
                      We Care Hospital,<br />
                      123 Health Avenue,<br />
                      Solapur, Maharashtra 413001
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                    <MedicalIcon name="Clock" className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-gray-950 text-base">Operating Hours</h4>
                    <p className="text-sm text-gray-650 leading-relaxed mt-1">
                      Mon–Sat: 8:00 AM – 8:00 PM <br />
                      <span className="font-bold text-red-650">Emergency Ward: 24/7 Support</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Phone & Email Details */}
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                    <MedicalIcon name="Phone" className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-gray-950 text-base">Call Desk</h4>
                    <p className="text-sm text-gray-650 mt-1 font-mono hover:text-blue-600">
                      <a href="tel:+91800932273">+91-800-WE-CARE</a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                    <MedicalIcon name="Mail" className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-gray-950 text-base">Direct Inbox</h4>
                    <p className="text-sm text-gray-650 mt-1 font-mono hover:text-blue-600">
                      <a href="mailto:contact@wecarehospital.in">contact@wecarehospital.in</a>
                    </p>
                  </div>
                </div>
              </div>

            </div>

            {/* Static Blue Vector Map Placeholder */}
            <div id="hospital-map-container" className="relative w-full aspect-16/9 bg-blue-50 border border-blue-100 rounded-3xl overflow-hidden shadow-xs flex flex-col items-center justify-center text-center p-6 min-h-[220px]">
              <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#1A73E8_1.5px,transparent_1.5px)] [background-size:24px_24px]"></div>
              
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 text-center flex flex-col items-center">
                <div className="p-3 bg-red-600 text-white rounded-full shadow-lg animate-bounce mb-3 relative">
                  <span className="animate-ping absolute inset-0 rounded-full bg-red-600 opacity-75"></span>
                  <MedicalIcon name="MapPin" className="w-6 h-6 text-white relative z-10" />
                </div>
                <h4 className="font-sans font-bold text-gray-900 text-sm">We Care Hospital Central Plaza</h4>
                <p className="text-xs text-gray-450 mt-0.5">Solapur, Maharashtra • 123 Health Avenue</p>
              </div>

              {/* Micro decoration representing roadways layout */}
              <div className="absolute top-1/3 left-0 right-0 h-1 bg-blue-105 pointer-events-none"></div>
              <div className="absolute top-0 bottom-0 left-1/3 w-1 bg-blue-105 pointer-events-none"></div>
              <div className="absolute top-0 bottom-0 left-2/3 w-1 bg-blue-105 pointer-events-none"></div>

              <div className="absolute bottom-3 right-4 font-mono text-[9px] text-gray-400 capitalize">
                visual map representation
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
