import React, { useState, useEffect, useRef } from 'react';
import { testimonials } from '../data/testimonials';
import { MedicalIcon } from './MedicalIcon';

export const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto play logic
  useEffect(() => {
    if (!isHovered) {
      timerRef.current = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
      }, 4000);
    }
    
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isHovered]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const setIndex = (index: number) => {
    setCurrentIndex(index);
  };

  return (
    <section id="testimonials-section" className="py-20 bg-blue-50/20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            What Our Patients Say
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            Discover real therapeutic success journeys told directly by our discharged patients.
          </p>
        </div>

        {/* Carousel Container */}
        <div 
          id="testimonials-slider"
          className="relative max-w-4xl mx-auto bg-white border border-gray-100/80 rounded-3xl p-8 sm:p-12 shadow-sm"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Quote mark decorator */}
          <span className="absolute top-6 left-8 text-7xl font-serif text-blue-100 pointer-events-none select-none">“</span>
          
          <div className="relative z-10 space-y-6">
            
            {/* 5-Star Ratings */}
            <div className="flex items-center gap-1 text-yellow-400">
              {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                <MedicalIcon key={i} name="Star" className="w-5 h-5 fill-current" />
              ))}
            </div>

            {/* Testimonials Quote text */}
            <blockquote className="font-sans text-gray-700 text-lg md:text-xl font-medium leading-relaxed italic">
              "{testimonials[currentIndex].quote}"
            </blockquote>

            {/* Patient Credentials & Treatment Badges */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-gray-100">
              <div>
                <cite className="not-italic font-sans font-extrabold text-gray-950 text-base block">
                  {testimonials[currentIndex].name}
                </cite>
                <span className="text-xs text-gray-400 block font-mono capitalize">Verified Discharge Patient</span>
              </div>
              <div className="bg-blue-50 text-blue-700 px-3 py-1.5 rounded-xl border border-blue-100/50 text-xs font-semibold w-fit">
                Treatment: {testimonials[currentIndex].treatment}
              </div>
            </div>

          </div>

          {/* Slider Arrow Navigation (Left / Right) */}
          <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 justify-between px-3 hidden sm:flex pointer-events-none">
            <button
              id="slider-btn-prev"
              onClick={handlePrev}
              className="bg-white hover:bg-blue-600 text-gray-500 hover:text-white p-2.5 rounded-full border border-gray-150 pointer-events-auto transition-colors shadow-xs cursor-pointer"
              aria-label="Previous testimonial"
            >
              <MedicalIcon name="ChevronLeft" className="w-5 h-5" />
            </button>
            <button
              id="slider-btn-next"
              onClick={handleNext}
              className="bg-white hover:bg-blue-600 text-gray-500 hover:text-white p-2.5 rounded-full border border-gray-150 pointer-events-auto transition-colors shadow-xs cursor-pointer"
              aria-label="Next testimonial"
            >
              <MedicalIcon name="ChevronRight" className="w-5 h-5" />
            </button>
          </div>

        </div>

        {/* Carousel indicator dots */}
        <div className="flex justify-center items-center gap-2.5 mt-8">
          {testimonials.map((_, i) => (
            <button
              id={`slider-dot-${i}`}
              key={i}
              onClick={() => setIndex(i)}
              className={`w-3.5 h-3.5 rounded-full border transition-all duration-200 cursor-pointer ${
                currentIndex === i 
                  ? 'bg-blue-600 border-blue-600 scale-110 shadow-sm' 
                  : 'bg-white border-gray-300 hover:bg-gray-100'
              }`}
              aria-label={`Jump to testimonial slide ${i + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
};
