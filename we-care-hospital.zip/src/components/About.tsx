import React from 'react';
import { MedicalIcon } from './MedicalIcon';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            About Our Medical Institution
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            Established in 1998, We Care Hospital combines advanced clinical excellence with a compassionate human touch to help build a healthier society.
          </p>
        </div>

        {/* Content Section: 2 Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-20">
          
          {/* Left Column: Image placeholder (blue-tinted rectangle with hospital icon) */}
          <div className="lg:col-span-5">
            <div className="relative w-full aspect-4/3 rounded-3xl bg-blue-50 border border-blue-100 shadow-sm flex flex-col items-center justify-center p-8 text-center overflow-hidden min-h-[320px]">
              <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(#1A73E8_1px,transparent_1px)] [background-size:16px_16px]"></div>
              <div className="p-5 bg-white text-blue-600 rounded-2xl shadow-md z-10 mb-4 scale-110">
                <MedicalIcon name="Ambulance" className="w-12 h-12 text-blue-600" />
              </div>
              <h3 className="font-sans font-extrabold text-gray-900 text-lg z-10">We Care Hospital Campus</h3>
              <p className="text-xs text-gray-400 font-mono mt-1 z-10">SOLAPUR CITY, MAHARASHTRA</p>
              <div className="mt-6 flex gap-4 text-xs z-10">
                <span className="bg-white border border-blue-100 rounded-lg px-3 py-1.5 text-blue-700 font-bold">Lush Campus</span>
                <span className="bg-white border border-blue-100 rounded-lg px-3 py-1.5 text-blue-700 font-bold">230+ Beds</span>
                <span className="bg-white border border-blue-100 rounded-lg px-3 py-1.5 text-blue-700 font-bold font-semibold">Trauma Center</span>
              </div>
            </div>
          </div>

          {/* Right Column: Content (Mission, Vision, Values) */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4">
              <h3 className="text-xl font-bold font-sans text-gray-900 border-l-4 border-blue-600 pl-3">
                Mission, Vision & Core Values
              </h3>
              <p className="text-gray-600 leading-relaxed">
                We Care Hospital is dedicated to raising the standard of healthcare. We integrate experienced medical specialists with modern diagnostics and surgical equipment to provide our patients with precise diagnoses and effective treatment outcomes.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100/30">
                <div className="flex items-center gap-2 text-blue-700 font-bold text-base mb-2">
                  <MedicalIcon name="Shield" className="w-5 h-5 text-blue-600" />
                  Our Mission
                </div>
                <p className="text-sm text-gray-600 leading-relaxed">
                  To deliver compassionate high-quality medical services with clinical precision and absolute ethical integrity.
                </p>
              </div>

              <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100/30">
                <div className="flex items-center gap-2 text-blue-700 font-bold text-base mb-2">
                  <MedicalIcon name="Eye" className="w-5 h-5 text-blue-600" />
                  Our Vision
                </div>
                <p className="text-sm text-gray-600 leading-relaxed">
                  To be the region\'s benchmark healthcare partner, renowned for clinical breakthroughs, healing environments, and medical leadership.
                </p>
              </div>
            </div>

            <div className="bg-blue-50/20 p-5 rounded-2xl border border-blue-50">
              <div className="text-gray-950 font-bold text-base mb-2">Our Operating Values</div>
              <ul className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                  Clinical Rigor
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                  Patient Safety First
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                  Absolute Honesty
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                  Healing Empathy
                </li>
              </ul>
            </div>
          </div>

        </div>

        {/* Why Choose Us Section */}
        <div className="border-t border-gray-100 pt-16">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h3 className="font-sans font-bold text-2xl text-gray-900">Why Choose We Care Hospital?</h3>
            <p className="text-sm text-gray-500 mt-2">Our standards are set to meet international safety and care parameters.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Cards (4 items) */}
            <div className="bg-white p-6 rounded-2xl border border-gray-100 hover:border-blue-100 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl w-fit mb-4">
                <MedicalIcon name="Users" className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="font-sans font-bold text-gray-900 text-base mb-2">Expert Doctors</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                Direct access to over 100 experienced, board-certified specialists with international fellowship backgrounds.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-gray-100 hover:border-blue-100 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl w-fit mb-4">
                <MedicalIcon name="Sun" className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="font-sans font-bold text-gray-900 text-base mb-2">Modern Equipment</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                Fully computerized pathology labs and high-end silent imaging units for faster, accurate diagnostic results.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-gray-100 hover:border-blue-100 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl w-fit mb-4">
                <MedicalIcon name="Clock" className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="font-sans font-bold text-gray-900 text-base mb-2">24/7 Support</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                Never-closing emergency triage, on-site pharmacy services, and trauma units working 24 hours daily.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-gray-100 hover:border-blue-100 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl w-fit mb-4">
                <MedicalIcon name="Heart" className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="font-sans font-bold text-gray-900 text-base mb-2">Patient-First Approach</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                Personalized care pathways, minimum wait times, transparent billing, and dedicated post-treatment care calls.
              </p>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
