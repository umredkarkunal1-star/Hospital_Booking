import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import { MedicalIcon } from './MedicalIcon';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Monitor scroll for a subtle shadow effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile drawer on route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  // Combined anchor or page transition
  const handleAnchorClick = (e: React.MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    e.preventDefault();
    if (location.pathname !== '/') {
      navigate('/#' + sectionId);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsOpen(false);
  };

  const activeClass = "text-blue-600 font-semibold border-b-2 border-blue-600 pb-1";
  const inactiveClass = "text-gray-600 hover:text-blue-600 transition-colors font-medium pb-1";

  return (
    <header className={`sticky top-0 z-50 w-full transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-3' : 'bg-white/95 py-4 border-b border-gray-100'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <Link id="nav-logo" to="/" className="flex items-center gap-2.5 group" aria-label="We Care Hospital Home">
            <div className="bg-blue-600 text-white p-2 rounded-xl group-hover:bg-blue-700 transition-colors shadow-sm">
              <MedicalIcon name="Heart" className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="font-sans font-bold text-xl tracking-tight text-gray-900">
                We Care <span className="text-blue-600">Hospital</span>
              </span>
              <span className="text-[10px] font-mono tracking-wider text-gray-400 capitalize">
                compassionate excellence
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8" aria-label="Main Navigation">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                isActive && location.hash === '' ? activeClass : inactiveClass
              }
            >
              Home
            </NavLink>
            <a 
              href="#about"
              onClick={(e) => handleAnchorClick(e, 'about')}
              className={location.pathname === '/' && location.hash === '#about' ? activeClass : inactiveClass}
            >
              About
            </a>
            <NavLink 
              to="/departments" 
              className={({ isActive }) => isActive ? activeClass : inactiveClass}
            >
              Departments
            </NavLink>
            <NavLink 
              to="/doctors" 
              className={({ isActive }) => isActive ? activeClass : inactiveClass}
            >
              Doctors
            </NavLink>
            <NavLink 
              to="/services" 
              className={({ isActive }) => isActive ? activeClass : inactiveClass}
            >
              Services
            </NavLink>
            <a 
              href="#blog"
              onClick={(e) => handleAnchorClick(e, 'blog')}
              className={location.pathname === '/' && location.hash === '#blog' ? activeClass : inactiveClass}
            >
              Blog
            </a>
            <NavLink 
              to="/contact" 
              className={({ isActive }) => isActive ? activeClass : inactiveClass}
            >
              Contact
            </NavLink>
          </nav>

          {/* Right Action Button */}
          <div className="hidden lg:flex items-center">
            <Link 
              id="nav-cta-button"
              to="/book-appointment" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-full font-semibold shadow-sm transition-all duration-200 hover:shadow-md transform hover:-translate-y-0.5 whitespace-nowrap"
            >
              Book Appointment
            </Link>
          </div>

          {/* Mobile hamburger menu button */}
          <div className="flex lg:hidden">
            <button
              id="hamburger-menu-btn"
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-lg text-gray-500 hover:text-blue-600 hover:bg-gray-50 focus:outline-none"
              aria-expanded={isOpen}
              aria-label="Toggle navigation menu"
            >
              {isOpen ? (
                <MedicalIcon name="X" className="block h-6 w-6" />
              ) : (
                <MedicalIcon name="Menu" className="block h-6 w-6" />
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-sm transition-opacity" onClick={() => setIsOpen(false)}>
          <nav 
            className="fixed inset-y-0 right-0 max-w-xs w-full bg-white shadow-xl flex flex-col p-6 space-y-6 animate-in slide-in-from-right duration-200"
            onClick={(e) => e.stopPropagation()}
            aria-label="Mobile Navigation"
          >
            <div className="flex items-center justify-between border-b pb-4">
              <span className="font-bold text-gray-900 text-lg">Menu Navigation</span>
              <button 
                id="close-menu-btn"
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-full text-gray-400 hover:bg-gray-100"
                aria-label="Close menu"
              >
                <MedicalIcon name="X" className="w-6 h-6" />
              </button>
            </div>

            <div className="flex flex-col space-y-4 font-semibold text-gray-700">
              <Link 
                to="/" 
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.pathname === '/' && location.hash === '' ? 'bg-blue-50 text-blue-600' : ''
                }`}
                onClick={() => setIsOpen(false)}
              >
                Home
              </Link>
              <a 
                href="#about"
                onClick={(e) => handleAnchorClick(e, 'about')}
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.hash === '#about' ? 'bg-blue-50 text-blue-600' : ''
                }`}
              >
                About
              </a>
              <Link 
                to="/departments" 
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.pathname === '/departments' ? 'bg-blue-50 text-blue-600' : ''
                }`}
                onClick={() => setIsOpen(false)}
              >
                Departments
              </Link>
              <Link 
                to="/doctors" 
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.pathname === '/doctors' ? 'bg-blue-50 text-blue-600' : ''
                }`}
                onClick={() => setIsOpen(false)}
              >
                Doctors
              </Link>
              <Link 
                to="/services" 
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.pathname === '/services' ? 'bg-blue-50 text-blue-600' : ''
                }`}
                onClick={() => setIsOpen(false)}
              >
                Services
              </Link>
              <a 
                href="#blog"
                onClick={(e) => handleAnchorClick(e, 'blog')}
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.hash === '#blog' ? 'bg-blue-50 text-blue-600' : ''
                }`}
              >
                Blog
              </a>
              <Link 
                to="/contact" 
                className={`py-2 px-3 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  location.pathname === '/contact' ? 'bg-blue-50 text-blue-600' : ''
                }`}
                onClick={() => setIsOpen(false)}
              >
                Contact
              </Link>
            </div>

            <div className="pt-6 border-t mt-auto">
              <Link 
                id="mobile-nav-cta-button"
                to="/book-appointment" 
                className="block text-center bg-blue-600 hover:bg-blue-700 text-white w-full py-3 rounded-xl font-bold shadow-sm transition-all duration-200"
                onClick={() => setIsOpen(false)}
              >
                Book Appointment
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
