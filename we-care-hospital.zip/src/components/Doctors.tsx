import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { doctors } from '../data/doctors';
import { departments } from '../data/departments';
import { MedicalIcon } from './MedicalIcon';

interface DoctorsProps {
  initialDepartmentId?: string;
  hideFilters?: boolean;
}

export const Doctors: React.FC<DoctorsProps> = ({ initialDepartmentId = 'all', hideFilters = false }) => {
  const [selectedDept, setSelectedDept] = useState<string>(initialDepartmentId);
  const navigate = useNavigate();

  // Keep state sync'd if initialDepartmentId changes (e.g. url param changes)
  useEffect(() => {
    if (initialDepartmentId) {
      setSelectedDept(initialDepartmentId);
    }
  }, [initialDepartmentId]);

  // Filter lists based on selection
  const filteredDoctors = selectedDept === 'all' 
    ? doctors 
    : doctors.filter(doc => doc.departmentId === selectedDept);

  const handleBookDoctor = (doctorId: string) => {
    navigate('/book-appointment', { state: { preselectedDoctorId: doctorId } });
  };

  return (
    <section id="doctors" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            Meet Our Specialists
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            Our medical staff consists of internationally trained medical specialists holding advanced credentials, operating on standard-setting patient outcome protocols.
          </p>
        </div>

        {/* Filter tabs */}
        {!hideFilters && (
          <div className="mb-12">
            <div className="flex flex-wrap justify-center gap-2 border-b border-gray-100 pb-6">
              <button
                id="filter-tab-all"
                onClick={() => setSelectedDept('all')}
                className={`px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200 cursor-pointer ${
                  selectedDept === 'all'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                }`}
              >
                All Specialists
              </button>
              {departments.map(dept => (
                <button
                  id={`filter-tab-${dept.id}`}
                  key={dept.id}
                  onClick={() => setSelectedDept(dept.id)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200 cursor-pointer ${
                    selectedDept === dept.id
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-gray-50 text-gray-600 hover:bg-blue-50 hover:text-blue-600'
                  }`}
                >
                  {dept.name}
                </button>
              ))}
            </div>
            <div className="text-center text-xs text-gray-400 font-mono mt-3">
              Showing {filteredDoctors.length} specialist{filteredDoctors.length !== 1 ? 's' : ''} in {selectedDept === 'all' ? 'all medical disciplines' : departments.find(d => d.id === selectedDept)?.name}
            </div>
          </div>
        )}

        {/* Grid display: 4 columns desktop, 2 tablet, 1 mobile */}
        {filteredDoctors.length === 0 ? (
          <div className="text-center py-16 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
            <MedicalIcon name="AlertTriangle" className="w-10 h-10 text-gray-400 mx-auto mb-3" />
            <h3 className="text-gray-700 font-semibold text-lg">No specialists found</h3>
            <p className="text-gray-400 text-sm mt-1">Please select another department filter above.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredDoctors.map(doc => (
              <div 
                key={doc.id}
                className="bg-white border border-gray-100 hover:border-blue-100 rounded-3xl p-6 text-center shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
              >
                {/* Visual Header/Avatar */}
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 rounded-full bg-blue-100 text-blue-700 font-bold text-2xl flex items-center justify-center shadow-xs mb-4 select-none group-hover:scale-105 transition-transform duration-200 border border-blue-50">
                    {doc.initials}
                  </div>
                  
                  {/* Doctor badge & name */}
                  <span className="text-[11px] font-mono font-bold tracking-wider uppercase text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full mb-2">
                    {doc.departmentName}
                  </span>
                  
                  <h3 className="font-sans font-bold text-gray-900 text-base line-clamp-1">
                    {doc.name}
                  </h3>
                  
                  <p className="text-[11px] text-gray-400 font-mono mt-1 line-clamp-1" title={doc.education}>
                    {doc.education}
                  </p>

                  <div className="mt-4 flex items-center gap-1.5 text-xs text-gray-500 font-medium bg-gray-50/50 py-1 px-3 rounded-lg border border-gray-100">
                    <MedicalIcon name="Award" className="w-4 h-4 text-gray-400" />
                    <span>{doc.experience} Years Experience</span>
                  </div>
                </div>

                {/* Book CTA Action button */}
                <div className="pt-6 mt-6 border-t border-gray-50">
                  <button
                    id={`doc-book-btn-${doc.id}`}
                    onClick={() => handleBookDoctor(doc.id)}
                    className="w-full bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white font-semibold text-sm py-2 px-4 rounded-xl transition-all duration-200 text-center cursor-pointer"
                  >
                    Book Appointment
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
