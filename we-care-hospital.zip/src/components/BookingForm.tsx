import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { departments } from '../data/departments';
import { doctors } from '../data/doctors';
import { MedicalIcon } from './MedicalIcon';
import { saveAppointment } from '../lib/supabase';

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  dob: string;
  gender: string;
  departmentId: string;
  doctorId: string;
  appointmentDate: string;
  timeSlot: string;
  reason: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  dob?: string;
  gender?: string;
  departmentId?: string;
  doctorId?: string;
  appointmentDate?: string;
  timeSlot?: string;
  reason?: string;
}

interface ConfirmationData {
  referenceNumber: string;
  patientName: string;
  doctorName: string;
  departmentName: string;
  appointmentDate: string;
  timeSlot: string;
}

export const BookingForm: React.FC = () => {
  const location = useLocation();
  
  // Initial default values
  const [formData, setFormData] = useState<FormState>({
    fullName: '',
    email: '',
    phone: '',
    dob: '',
    gender: '',
    departmentId: '',
    doctorId: '',
    appointmentDate: '',
    timeSlot: '',
    reason: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [confirmation, setConfirmation] = useState<ConfirmationData | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Monitor location state for preselected doctor (e.g., booked from the Doctors tab)
  useEffect(() => {
    const routeState = location.state as { preselectedDoctorId?: string } | null;
    if (routeState && routeState.preselectedDoctorId) {
      const doctor = doctors.find(d => d.id === routeState.preselectedDoctorId);
      if (doctor) {
        setFormData(prev => ({
          ...prev,
          departmentId: doctor.departmentId,
          doctorId: doctor.id
        }));
      }
    }
  }, [location.state]);

  // Handle department changes (reset selected doctor if they are not in the new department)
  const handleDepartmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const nextDeptId = e.target.value;
    setFormData(prev => ({
      ...prev,
      departmentId: nextDeptId,
      doctorId: '' // Reset doctor
    }));
    if (errors.departmentId) {
      setErrors(prev => ({ ...prev, departmentId: undefined }));
    }
  };

  // Get filtered doctors list for the current selected department
  const filteredDoctors = formData.departmentId
    ? doctors.filter(doc => doc.departmentId === formData.departmentId)
    : [];

  // Generic value change handler
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Auto clear errors for that field
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  // Validation function
  const validateForm = (): boolean => {
    const tempErrors: FormErrors = {};
    
    if (!formData.fullName.trim()) {
      tempErrors.fullName = 'Full Name is required.';
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      tempErrors.email = 'Email Address is required.';
    } else if (!emailRegex.test(formData.email)) {
      tempErrors.email = 'Format description is invalid (e.g., user@example.com).';
    }
    
    const phoneRegex = /^[0-9]{10}$/;
    if (!formData.phone.trim()) {
      tempErrors.phone = 'Phone Number is required.';
    } else if (!phoneRegex.test(formData.phone)) {
      tempErrors.phone = 'Should be a valid 10-digit phone number.';
    }
    
    if (!formData.dob) {
      tempErrors.dob = 'Date of Birth is required.';
    }
    
    if (!formData.gender) {
      tempErrors.gender = 'Please select a gender.';
    }
    
    if (!formData.departmentId) {
      tempErrors.departmentId = 'Please select a medical department.';
    }
    
    if (!formData.doctorId) {
      tempErrors.doctorId = 'Please select a specialist.';
    }
    
    if (!formData.appointmentDate) {
      tempErrors.appointmentDate = 'Appointment Date is required.';
    } else {
      const selectedDate = new Date(formData.appointmentDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0); // reset clock for comparison
      if (selectedDate <= today) {
        tempErrors.appointmentDate = 'Preferred appointment date must be in the future.';
      }
    }
    
    if (!formData.timeSlot) {
      tempErrors.timeSlot = 'Please select a preferred time slot.';
    }
    
    if (!formData.reason.trim()) {
      tempErrors.reason = 'Please state your symptoms or reasoning.';
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    setSubmitError(null);

    try {
      const matchedDoctor = doctors.find(d => d.id === formData.doctorId);
      const matchedDepartment = departments.find(d => d.id === formData.departmentId);
      
      // Auto-generate reference number
      const randomId = Math.floor(1000 + Math.random() * 9000);
      const referenceNum = `WCH-2026-${randomId}`;

      // Save to Supabase backend table 'appointments'
      await saveAppointment({
        reference_number: referenceNum,
        full_name: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        dob: formData.dob,
        gender: formData.gender,
        department_id: formData.departmentId,
        doctor_id: formData.doctorId,
        appointment_date: formData.appointmentDate,
        time_slot: formData.timeSlot,
        reason: formData.reason
      });

      setConfirmation({
        referenceNumber: referenceNum,
        patientName: formData.fullName,
        doctorName: matchedDoctor ? matchedDoctor.name : 'Medical Staff Member',
        departmentName: matchedDepartment ? matchedDepartment.name : 'General Practice',
        appointmentDate: formData.appointmentDate,
        timeSlot: formData.timeSlot
      });

      // Optional: scroll confirmation into view
      window.scrollTo({ top: 300, behavior: 'smooth' });
    } catch (err: any) {
      console.error('Failed to submit booking to Supabase:', err);
      setSubmitError(err.message || 'An unexpected error occurred while saving your appointment in our database. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      dob: '',
      gender: '',
      departmentId: '',
      doctorId: '',
      appointmentDate: '',
      timeSlot: '',
      reason: ''
    });
    setErrors({});
    setConfirmation(null);
    setSubmitError(null);
  };

  return (
    <section id="booking-section" className="py-20 bg-blue-50/10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            Book Appointment
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            Fill in the medical registry details below to generate a validated appointments queue reference within our specialist roster.
          </p>
        </div>

        {confirmation ? (
          /* Confirmation State UI CARD */
          <div id="booking-confirmation-card" className="bg-white border border-green-150 rounded-3xl p-8 shadow-lg max-w-2xl mx-auto text-center space-y-6 animate-in zoom-in-95 duration-300">
            <div className="mx-auto block text-green-600 bg-green-50 p-4 rounded-full w-fit">
              <MedicalIcon name="CheckCircle" className="w-16 h-16" />
            </div>
            
            <div className="space-y-2">
              <h3 className="font-sans font-extrabold text-2xl text-gray-950">Appointment Confirmed!</h3>
              <p className="text-sm text-gray-500">Your clinical allocation is safely registered in our medical desk.</p>
            </div>

            <div className="bg-gray-50/80 rounded-2xl p-6 border border-gray-100 text-left space-y-4">
              <div className="flex justify-between border-b border-gray-100 pb-3">
                <span className="text-xs font-mono text-gray-400 capitalize">Reference ID:</span>
                <span className="font-mono font-bold text-blue-600 text-sm tracking-wide">{confirmation.referenceNumber}</span>
              </div>
              <div className="flex justify-between border-b border-gray-100 pb-3">
                <span className="text-sm text-gray-500 font-medium">Patient Registered:</span>
                <span className="font-sans font-semibold text-gray-900 text-sm">{confirmation.patientName}</span>
              </div>
              <div className="flex justify-between border-b border-gray-100 pb-3">
                <span className="text-sm text-gray-500 font-medium">Clinical Roster:</span>
                <span className="font-sans font-semibold text-gray-900 text-sm">{confirmation.doctorName}</span>
              </div>
              <div className="flex justify-between border-b border-gray-100 pb-3">
                <span className="text-sm text-gray-500 font-medium">Department Area:</span>
                <span className="font-sans font-semibold text-gray-900 text-sm">{confirmation.departmentName}</span>
              </div>
              <div className="flex justify-between pb-1">
                <span className="text-sm text-gray-500 font-medium">Time & Date Block:</span>
                <span className="font-sans font-semibold text-gray-900 text-sm">{confirmation.appointmentDate} at {confirmation.timeSlot}</span>
              </div>
            </div>

            <div className="text-xs text-gray-400 leading-relaxed font-mono">
              ★ Please reach our primary billing desk 15 minutes before your selected time slot carrying relevant historical laboratory scripts.
            </div>

            <button
              id="booking-reset-btn"
              onClick={handleReset}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-sm cursor-pointer"
            >
              Book Another Appointment
            </button>
          </div>
        ) : (
          /* Form UI */
          <div className="bg-white border border-gray-100 rounded-3xl p-6 sm:p-10 shadow-md relative overflow-hidden">
            
            {/* Loading Overlay Spinner */}
            {isLoading && (
              <div className="absolute inset-0 bg-white/70 backdrop-blur-xs flex flex-col items-center justify-center z-30">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-blue-700 font-semibold text-sm mt-4 font-mono">Verifying doctor rosters...</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6" noValidate>
              
              {submitError && (
                <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm leading-relaxed space-y-2 select-none">
                  <p className="font-extrabold flex items-center gap-1.5 text-red-800">
                    <span>⚠️ Database Submission Issue</span>
                  </p>
                  <p className="opacity-90">{submitError}</p>
                  <p className="text-xs pt-1 opacity-75 font-mono">
                    Please ensure you have created the `appointments` table on your Supabase dashboard using the SQL provided in the instructions!
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Full Name */}
                <div>
                  <label htmlFor="fullName" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    className={`w-full border rounded-xl px-4 py-2.5 outline-none transition-all text-sm ${
                      errors.fullName ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    placeholder="Enter your full name"
                    disabled={isLoading}
                    required
                  />
                  {errors.fullName && <p className="text-xs text-red-500 mt-1 font-medium">{errors.fullName}</p>}
                </div>

                {/* Email Address */}
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full border rounded-xl px-4 py-2.5 outline-none transition-all text-sm ${
                      errors.email ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    placeholder="user@example.com"
                    disabled={isLoading}
                    required
                  />
                  {errors.email && <p className="text-xs text-red-500 mt-1 font-medium">{errors.email}</p>}
                </div>

                {/* Phone Number */}
                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className={`w-full border rounded-xl px-4 py-2.5 outline-none transition-all text-sm ${
                      errors.phone ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    placeholder="10-digit mobile number"
                    disabled={isLoading}
                    required
                  />
                  {errors.phone && <p className="text-xs text-red-500 mt-1 font-medium">{errors.phone}</p>}
                </div>

                {/* DOB Picker */}
                <div>
                  <label htmlFor="dob" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Date of Birth <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="dob"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    className={`w-full border rounded-xl px-4 py-2.5 outline-none transition-all text-sm ${
                      errors.dob ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    disabled={isLoading}
                    required
                  />
                  {errors.dob && <p className="text-xs text-red-500 mt-1 font-medium">{errors.dob}</p>}
                </div>

              </div>

              {/* Gender Selection Radio Cluster */}
              <div>
                <span className="block text-sm font-semibold text-gray-700 mb-2">
                  Gender Selection <span className="text-red-500">*</span>
                </span>
                <div className="flex flex-wrap items-center gap-6 mt-1">
                  <label className="inline-flex items-center gap-2 text-sm text-gray-600 font-medium cursor-pointer">
                    <input
                      type="radio"
                      name="gender"
                      value="Male"
                      checked={formData.gender === 'Male'}
                      onChange={handleChange}
                      className="w-4 h-4 text-blue-600 focus:ring-blue-550 border-gray-300"
                      disabled={isLoading}
                    />
                    Male
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm text-gray-600 font-medium cursor-pointer">
                    <input
                      type="radio"
                      name="gender"
                      value="Female"
                      checked={formData.gender === 'Female'}
                      onChange={handleChange}
                      className="w-4 h-4 text-blue-600 focus:ring-blue-550 border-gray-300"
                      disabled={isLoading}
                    />
                    Female
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm text-gray-600 font-medium cursor-pointer">
                    <input
                      type="radio"
                      name="gender"
                      value="Other"
                      checked={formData.gender === 'Other'}
                      onChange={handleChange}
                      className="w-4 h-4 text-blue-600 focus:ring-blue-550 border-gray-300"
                      disabled={isLoading}
                    />
                    Other / Declined
                  </label>
                </div>
                {errors.gender && <p className="text-xs text-red-500 mt-1 font-medium">{errors.gender}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Department Dropdown */}
                <div>
                  <label htmlFor="departmentId" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Select Department <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="departmentId"
                    name="departmentId"
                    value={formData.departmentId}
                    onChange={handleDepartmentChange}
                    className={`w-full border bg-white rounded-xl px-4 py-2.5 outline-none transition-all text-sm appearance-none ${
                      errors.departmentId ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    disabled={isLoading}
                    required
                  >
                    <option value="">-- Choose Department --</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                  {errors.departmentId && <p className="text-xs text-red-500 mt-1 font-medium">{errors.departmentId}</p>}
                </div>

                {/* Doctor Dynamic Dropdown */}
                <div>
                  <label htmlFor="doctorId" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Select Doctor / Specialist <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="doctorId"
                    name="doctorId"
                    value={formData.doctorId}
                    onChange={handleChange}
                    className={`w-full border bg-white rounded-xl px-4 py-2.5 outline-none transition-all text-sm appearance-none ${
                      errors.doctorId ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    disabled={isLoading || !formData.departmentId}
                    required
                  >
                    <option value="">
                      {!formData.departmentId ? 'Select department first' : '-- Choose Doctor --'}
                    </option>
                    {filteredDoctors.map(doc => (
                      <option key={doc.id} value={doc.id}>{doc.name} ({doc.education})</option>
                    ))}
                  </select>
                  {errors.doctorId && <p className="text-xs text-red-500 mt-1 font-medium">{errors.doctorId}</p>}
                </div>

              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Appointment Date */}
                <div>
                  <label htmlFor="appointmentDate" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Preferred Appointment Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="appointmentDate"
                    name="appointmentDate"
                    value={formData.appointmentDate}
                    onChange={handleChange}
                    className={`w-full border rounded-xl px-4 py-2.5 outline-none transition-all text-sm ${
                      errors.appointmentDate ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    disabled={isLoading}
                    required
                  />
                  {errors.appointmentDate && <p className="text-xs text-red-500 mt-1 font-medium">{errors.appointmentDate}</p>}
                </div>

                {/* Appointment Time Session */}
                <div>
                  <label htmlFor="timeSlot" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Preferred Time Slot <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="timeSlot"
                    name="timeSlot"
                    value={formData.timeSlot}
                    onChange={handleChange}
                    className={`w-full border bg-white rounded-xl px-4 py-2.5 outline-none transition-all text-sm ${
                      errors.timeSlot ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                    }`}
                    disabled={isLoading}
                    required
                  >
                    <option value="">-- Choose Slot --</option>
                    <option value="9:00 AM">9:00 AM</option>
                    <option value="10:00 AM">10:00 AM</option>
                    <option value="11:00 AM">11:00 AM</option>
                    <option value="12:00 PM">12:00 PM</option>
                    <option value="2:00 PM">2:00 PM</option>
                    <option value="3:00 PM">3:00 PM</option>
                    <option value="4:00 PM">4:00 PM</option>
                    <option value="5:00 PM">5:00 PM</option>
                  </select>
                  {errors.timeSlot && <p className="text-xs text-red-500 mt-1 font-medium">{errors.timeSlot}</p>}
                </div>

              </div>

              {/* Symptoms Textarea */}
              <div>
                <label htmlFor="reason" className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Reason for Visit / Symptoms <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="reason"
                  name="reason"
                  value={formData.reason}
                  onChange={handleChange}
                  rows={4}
                  className={`w-full border rounded-xl px-4 py-2.5 outline-none transition-all text-sm resize-none ${
                    errors.reason ? 'border-red-400 focus:border-red-500' : 'border-gray-200 focus:border-blue-500'
                  }`}
                  placeholder="Tell us briefly about your medical symptoms, chronic diagnoses, or requirements..."
                  disabled={isLoading}
                  required
                ></textarea>
                {errors.reason && <p className="text-xs text-red-500 mt-1 font-medium">{errors.reason}</p>}
              </div>

              {/* Submit CTA button */}
              <button
                id="booking-submit-btn"
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-200 transition-colors duration-200 cursor-pointer"
                disabled={isLoading}
              >
                Submit Appointment Request
              </button>

            </form>
          </div>
        )}

      </div>
    </section>
  );
};
