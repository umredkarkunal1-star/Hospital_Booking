import React from 'react';
import { services } from '../data/services';
import { MedicalIcon } from './MedicalIcon';

export const Services: React.FC = () => {
  return (
    <section id="services-section" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            Our Professional Healthcare Services
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            From round-the-clock emergency responses and specialized intensive care units to custom executive preventive panels, discover our world-caliber patient systems.
          </p>
        </div>

        {/* 3-column Service grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div 
              key={service.id}
              className="bg-white p-6 rounded-3xl border border-gray-100 hover:border-blue-100 shadow-sm hover:shadow-md transition-all duration-300 flex items-start gap-4 group"
            >
              <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition-all duration-300 shrink-0">
                <MedicalIcon name={service.iconName} className="w-6 h-6" />
              </div>
              
              <div className="space-y-1.5">
                <h3 className="font-sans font-bold text-gray-900 text-base md:text-lg group-hover:text-blue-600 transition-colors duration-200">
                  {service.title}
                </h3>
                <p className="text-sm text-gray-550 leading-relaxed line-clamp-2" title={service.description}>
                  {service.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Help Box */}
        <div className="mt-16 bg-blue-50/50 rounded-2xl p-6 border border-blue-100/30 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="p-2.5 bg-blue-105 text-blue-700 rounded-xl">
              <MedicalIcon name="Video" className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-sans font-bold text-gray-950 text-sm">Need remote consultation instead?</h4>
              <p className="text-xs text-gray-500 mt-0.5">Connect with senior specialists via our HD secure Telemedicine portal.</p>
            </div>
          </div>
          <a
            id="services-tele-btn"
            href="#contact"
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-5 py-2.5 rounded-full shadow-xs shrink-0"
          >
            Inquire About Telehealth
          </a>
        </div>

      </div>
    </section>
  );
};
