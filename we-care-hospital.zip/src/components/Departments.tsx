import React from 'react';
import { Link } from 'react-router-dom';
import { departments } from '../data/departments';
import { MedicalIcon } from './MedicalIcon';

export const Departments: React.FC = () => {
  return (
    <section id="departments" className="py-20 bg-blue-50/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-sans font-bold text-3xl sm:text-4xl text-gray-900 tracking-tight">
            Our Specialist Departments
          </h2>
          <div className="h-1 w-16 bg-blue-600 mx-auto mt-4 rounded-full"></div>
          <p className="font-sans text-gray-600 mt-4 leading-relaxed">
            We Care Hospital offers comprehensive care across 15 distinct specialist domains. Select a department to find appropriate clinical advisors.
          </p>
        </div>

        {/* Departments responsive grid (3 col desktop, 2 tablet, 1 mobile) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {departments.map((dept) => (
            <div 
              key={dept.id} 
              className="bg-white p-6 rounded-2xl border border-gray-100/80 shadow-sm hover:shadow-md hover:border-blue-200 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="p-3 bg-blue-50 text-blue-600 rounded-xl w-fit mb-4 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-200">
                  <MedicalIcon name={dept.iconName} className="w-6 h-6" />
                </div>
                <h3 className="font-sans font-bold text-gray-900 text-lg mb-2">
                  {dept.name}
                </h3>
                <p className="text-sm text-gray-650 leading-relaxed mb-6">
                  {dept.description}
                </p>
              </div>

              <Link 
                id={`dept-view-doc-${dept.id}`}
                to={`/doctors/${dept.id}`}
                className="inline-flex items-center gap-1 text-sm font-semibold text-blue-600 hover:text-blue-700 hover:underline mt-auto w-fit"
                aria-label={`View clinical doctors specialized in ${dept.name}`}
              >
                View Doctors 
                <MedicalIcon name="ArrowRight" className="w-4 h-4" />
              </Link>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
