import { createClient } from '@supabase/supabase-js';

// Retrieve the Supabase configuration from environment variables
// with safe fallbacks to the credentials provided by the user.
const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://sxitpvqogtmloipvwgxg.supabase.co';
const supabaseKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_aWNPcPGQYxDaCzWbjUC8Yg_J0G45cB-';

export const supabase = createClient(supabaseUrl, supabaseKey);

export interface AppointmentData {
  reference_number: string;
  full_name: string;
  email: string;
  phone: string;
  dob: string;
  gender: string;
  department_id: string;
  doctor_id: string;
  appointment_date: string;
  time_slot: string;
  reason: string;
}

/**
 * Saves a new appointment booking to the Supabase 'appointments' table.
 */
export async function saveAppointment(data: AppointmentData) {
  const { data: insertedData, error } = await supabase
    .from('appointments')
    .insert([data])
    .select();

  if (error) {
    console.error('Supabase booking insert error:', error);
    throw error;
  }

  return insertedData;
}
