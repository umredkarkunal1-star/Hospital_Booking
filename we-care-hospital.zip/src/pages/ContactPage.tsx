import React, { useEffect } from 'react';
import { Contact } from '../components/Contact';

export const ContactPage: React.FC = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  return (
    <div id="contact-page-root" className="w-full">
      {/* Page Header banner */}
      <div className="bg-blue-600 text-white py-16 text-center select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-sans font-extrabold text-3xl sm:text-4xl">Contact Our Registry Desk</h1>
          <p className="text-blue-105 text-sm sm:text-base mt-2 max-w-2xl mx-auto font-medium">
            Find direct connection details, send custom inquiries, and locate our central hospital plaza.
          </p>
        </div>
      </div>

      {/* Renders details & forms */}
      <Contact />
    </div>
  );
};
