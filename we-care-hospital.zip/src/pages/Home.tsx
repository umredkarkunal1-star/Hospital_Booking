import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Hero } from '../components/Hero';
import { About } from '../components/About';
import { Departments } from '../components/Departments';
import { Doctors } from '../components/Doctors';
import { Services } from '../components/Services';
import { BookingForm } from '../components/BookingForm';
import { Testimonials } from '../components/Testimonials';
import { Blog } from '../components/Blog';
import { Contact } from '../components/Contact';

export const Home: React.FC = () => {
  const location = useLocation();

  useEffect(() => {
    // Scroll window to top on default loading
    if (!location.hash) {
      window.scrollTo({ top: 0, behavior: 'instant' });
    } else {
      // Dynamic delayed anchor scroll to let layouts calculate bounds
      const timer = setTimeout(() => {
        const id = location.hash.replace('#', '');
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [location.pathname, location.hash]);

  return (
    <main id="homepage-root" className="w-full">
      {/* Hero section */}
      <Hero />
      
      {/* About Section */}
      <About />
      
      {/* Departments Section */}
      <Departments />
      
      {/* Doctors section */}
      <Doctors />
      
      {/* Services listing components section */}
      <Services />
      
      {/* Booking Form section */}
      <BookingForm />
      
      {/* Testimonials section */}
      <Testimonials />
      
      {/* Blog articles section */}
      <Blog />
      
      {/* Contact information details */}
      <Contact />
    </main>
  );
};
