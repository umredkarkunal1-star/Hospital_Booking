import React, { useEffect } from 'react';
import { Departments } from '../components/Departments';

export const DepartmentsPage: React.FC = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  return (
    <div id="departments-page-root" className="w-full">
      {/* Page Header banner */}
      <div className="bg-blue-600 text-white py-16 text-center select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-sans font-extrabold text-3xl sm:text-4xl">Our Specialized Departments</h1>
          <p className="text-blue-105 text-sm sm:text-base mt-2 max-w-2xl mx-auto font-medium">
            Explore We Care Hospital’s 15 medical centers of excellence, crafted around expert diagnostic standards.
          </p>
        </div>
      </div>
      
      {/* Renders card list */}
      <Departments />
    </div>
  );
};
