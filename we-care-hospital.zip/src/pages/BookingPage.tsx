import React, { useEffect } from 'react';
import { BookingForm } from '../components/BookingForm';

export const BookingPage: React.FC = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  return (
    <div id="booking-page-root" className="w-full bg-slate-50/50">
      {/* Page Header banner */}
      <div className="bg-blue-600 text-white py-16 text-center select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-sans font-extrabold text-3xl sm:text-4xl">Book Your Hospital Visit</h1>
          <p className="text-blue-105 text-sm sm:text-base mt-2 max-w-2xl mx-auto font-medium">
            Formally book clinical slots, schedule preventive tests, or request specialists consultations.
          </p>
        </div>
      </div>

      {/* Booking Form Layout wrapper */}
      <div className="py-10">
        <BookingForm />
      </div>
    </div>
  );
};
