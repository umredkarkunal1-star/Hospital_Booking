import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Doctors } from '../components/Doctors';

export const DoctorsPage: React.FC = () => {
  const { departmentId } = useParams<{ departmentId?: string }>();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [departmentId]);

  return (
    <div id="doctors-page-root" className="w-full">
      {/* Page Header banner */}
      <div className="bg-blue-600 text-white py-16 text-center select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-sans font-extrabold text-3xl sm:text-4xl">Meet Our Specialist Physicians</h1>
          <p className="text-blue-105 text-sm sm:text-base mt-2 max-w-2xl mx-auto font-medium">
            Contact and schedule treatments with our board-certified clinical leaders and consulting advisors.
          </p>
        </div>
      </div>

      {/* Renders filterable Doctors grid */}
      <Doctors initialDepartmentId={departmentId || 'all'} />
    </div>
  );
};
