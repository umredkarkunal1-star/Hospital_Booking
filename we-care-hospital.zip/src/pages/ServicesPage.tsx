import React, { useEffect } from 'react';
import { Services } from '../components/Services';

export const ServicesPage: React.FC = () => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  return (
    <div id="services-page-root" className="w-full">
      {/* Page Header banner */}
      <div className="bg-blue-600 text-white py-16 text-center select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-sans font-extrabold text-3xl sm:text-4xl">Clinical Care Services</h1>
          <p className="text-blue-105 text-sm sm:text-base mt-2 max-w-2xl mx-auto font-medium">
            Discover our spectrum of modular clinical solutions including diagnostic laboratories, high-tech operation theatres, and 24/7 critical trauma teams.
          </p>
        </div>
      </div>

      {/* Renders card list */}
      <Services />
    </div>
  );
};
