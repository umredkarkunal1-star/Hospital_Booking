import { Doctor } from '../types';

export const doctors: Doctor[] = [
  // Cardiology
  {
    id: 'dr-priya-sharma',
    name: 'Dr. Priya Sharma',
    departmentId: 'cardiology',
    departmentName: 'Cardiology',
    experience: 15,
    education: 'MD (Cardiology), DM (Cardiology)',
    availability: ['Monday', 'Wednesday', 'Friday'],
    initials: 'PS'
  },
  {
    id: 'dr-robert-miller',
    name: 'Dr. Robert Miller',
    departmentId: 'cardiology',
    departmentName: 'Cardiology',
    experience: 12,
    education: 'MD, FACC',
    availability: ['Tuesday', 'Thursday', 'Saturday'],
    initials: 'RM'
  },
  // Neurology
  {
    id: 'dr-rohan-joshi',
    name: 'Dr. Rohan Joshi',
    departmentId: 'neurology',
    departmentName: 'Neurology',
    experience: 14,
    education: 'MD (Neurology), DM (Neurology)',
    availability: ['Monday', 'Tuesday', 'Wednesday'],
    initials: 'RJ'
  },
  {
    id: 'dr-sarah-chen',
    name: 'Dr. Sarah Chen',
    departmentId: 'neurology',
    departmentName: 'Neurology',
    experience: 11,
    education: 'MD, PhD (Neuroscience)',
    availability: ['Thursday', 'Friday', 'Saturday'],
    initials: 'SC'
  },
  // Orthopedics
  {
    id: 'dr-amit-patil',
    name: 'Dr. Amit Patil',
    departmentId: 'orthopedics',
    departmentName: 'Orthopedics',
    experience: 16,
    education: 'MS (Orthopedics), M.Ch',
    availability: ['Monday', 'Wednesday', 'Thursday'],
    initials: 'AP'
  },
  {
    id: 'dr-brenda-wright',
    name: 'Dr. Brenda Wright',
    departmentId: 'orthopedics',
    departmentName: 'Orthopedics',
    experience: 10,
    education: 'MD, Board Certified Joint Specialist',
    availability: ['Tuesday', 'Friday', 'Saturday'],
    initials: 'BW'
  },
  // Pediatrics
  {
    id: 'dr-nilesh-mehta',
    name: 'Dr. Nilesh Mehta',
    departmentId: 'pediatrics',
    departmentName: 'Pediatrics',
    experience: 13,
    education: 'MD (Pediatrics), DCH',
    availability: ['Monday', 'Tuesday', 'Friday'],
    initials: 'NM'
  },
  {
    id: 'dr-alice-johnson',
    name: 'Dr. Alice Johnson',
    departmentId: 'pediatrics',
    departmentName: 'Pediatrics',
    experience: 18,
    education: 'MD, FAAP',
    availability: ['Wednesday', 'Thursday', 'Saturday'],
    initials: 'AJ'
  },
  // Oncology
  {
    id: 'dr-vikram-rao',
    name: 'Dr. Vikram Rao',
    departmentId: 'oncology',
    departmentName: 'Oncology',
    experience: 17,
    education: 'MD, DM (Medical Oncology)',
    availability: ['Monday', 'Tuesday', 'Thursday'],
    initials: 'VR'
  },
  {
    id: 'dr-emily-watson',
    name: 'Dr. Emily Watson',
    departmentId: 'oncology',
    departmentName: 'Oncology',
    experience: 12,
    education: 'MD, FRCP',
    availability: ['Wednesday', 'Friday', 'Saturday'],
    initials: 'EW'
  },
  // Dermatology
  {
    id: 'dr-sneha-reddy',
    name: 'Dr. Sneha Reddy',
    departmentId: 'dermatology',
    departmentName: 'Dermatology',
    experience: 9,
    education: 'MD (Dermatology), DDV',
    availability: ['Monday', 'Wednesday', 'Friday'],
    initials: 'SR'
  },
  {
    id: 'dr-james-anderson',
    name: 'Dr. James Anderson',
    departmentId: 'dermatology',
    departmentName: 'Dermatology',
    experience: 14,
    education: 'MD, FAAD',
    availability: ['Tuesday', 'Thursday', 'Saturday'],
    initials: 'JA'
  },
  // Gynecology
  {
    id: 'dr-ananya-deshmukh',
    name: 'Dr. Ananya Deshmukh',
    departmentId: 'gynecology',
    departmentName: 'Gynecology',
    experience: 15,
    education: 'MS (OBGYN), DGO',
    availability: ['Monday', 'Tuesday', 'Thursday'],
    initials: 'AD'
  },
  {
    id: 'dr-karen-taylor',
    name: 'Dr. Karen Taylor',
    departmentId: 'gynecology',
    departmentName: 'Gynecology',
    experience: 13,
    education: 'MD, FACOG',
    availability: ['Wednesday', 'Friday', 'Saturday'],
    initials: 'KT'
  },
  // Ophthalmology
  {
    id: 'dr-sameer-kulkarni',
    name: 'Dr. Sameer Kulkarni',
    departmentId: 'ophthalmology',
    departmentName: 'Ophthalmology',
    experience: 14,
    education: 'MS (Ophthalmology)',
    availability: ['Monday', 'Wednesday', 'Friday'],
    initials: 'SK'
  },
  {
    id: 'dr-laura-davis',
    name: 'Dr. Laura Davis',
    departmentId: 'ophthalmology',
    departmentName: 'Ophthalmology',
    experience: 10,
    education: 'MD, Board Certified Vision Surgeon',
    availability: ['Tuesday', 'Thursday', 'Saturday'],
    initials: 'LD'
  },
  // ENT
  {
    id: 'dr-manoj-shinde',
    name: 'Dr. Manoj Shinde',
    departmentId: 'ent',
    departmentName: 'ENT',
    experience: 11,
    education: 'MS (ENT), DLO',
    availability: ['Monday', 'Wednesday', 'Thursday'],
    initials: 'MS'
  },
  {
    id: 'dr-david-taylor',
    name: 'Dr. David Taylor',
    departmentId: 'ent',
    departmentName: 'ENT',
    experience: 15,
    education: 'MD, FRCS Specialist',
    availability: ['Tuesday', 'Friday', 'Saturday'],
    initials: 'DT'
  },
  // Gastroenterology
  {
    id: 'dr-sandeep-kadam',
    name: 'Dr. Sandeep Kadam',
    departmentId: 'gastroenterology',
    departmentName: 'Gastroenterology',
    experience: 13,
    education: 'MD, DM (Gastroenterology)',
    availability: ['Monday', 'Tuesday', 'Wednesday'],
    initials: 'SK'
  },
  {
    id: 'dr-susan-thomas',
    name: 'Dr. Susan Thomas',
    departmentId: 'gastroenterology',
    departmentName: 'Gastroenterology',
    experience: 12,
    education: 'MD, FACG',
    availability: ['Thursday', 'Friday', 'Saturday'],
    initials: 'ST'
  },
  // Pulmonology
  {
    id: 'dr-rajesh-kadam',
    name: 'Dr. Rajesh Kadam',
    departmentId: 'pulmonology',
    departmentName: 'Pulmonology',
    experience: 16,
    education: 'MD (Pulmonary Medicine), FCCN',
    availability: ['Monday', 'Wednesday', 'Friday'],
    initials: 'RK'
  },
  {
    id: 'dr-linda-lopez',
    name: 'Dr. Linda Lopez',
    departmentId: 'pulmonology',
    departmentName: 'Pulmonology',
    experience: 10,
    education: 'MD (Pulmonology)',
    availability: ['Tuesday', 'Thursday', 'Saturday'],
    initials: 'LL'
  },
  // Urology
  {
    id: 'dr-vijay-phadke',
    name: 'Dr. Vijay Phadke',
    departmentId: 'urology',
    departmentName: 'Urology',
    experience: 18,
    education: 'MS, M.Ch (Urology)',
    availability: ['Monday', 'Wednesday', 'Thursday'],
    initials: 'VP'
  },
  {
    id: 'dr-charles-harris',
    name: 'Dr. Charles Harris',
    departmentId: 'urology',
    departmentName: 'Urology',
    experience: 11,
    education: 'MD, FACS',
    availability: ['Tuesday', 'Friday', 'Saturday'],
    initials: 'CH'
  },
  // Psychiatry
  {
    id: 'dr-ashutosh-ghorpade',
    name: 'Dr. Ashutosh Ghorpade',
    departmentId: 'psychiatry',
    departmentName: 'Psychiatry',
    experience: 12,
    education: 'MD (Psychiatry), DPM',
    availability: ['Monday', 'Tuesday', 'Wednesday'],
    initials: 'AG'
  },
  {
    id: 'dr-mary-wilson',
    name: 'Dr. Mary Wilson',
    departmentId: 'psychiatry',
    departmentName: 'Psychiatry',
    experience: 15,
    education: 'MD, FAPA',
    availability: ['Thursday', 'Friday', 'Saturday'],
    initials: 'MW'
  },
  // Radiology
  {
    id: 'dr-shruti-gore',
    name: 'Dr. Shruti Gore',
    departmentId: 'radiology',
    departmentName: 'Radiology',
    experience: 11,
    education: 'MD (Radiodiagnosis)',
    availability: ['Monday', 'Wednesday', 'Friday'],
    initials: 'SG'
  },
  {
    id: 'dr-thomas-clark',
    name: 'Dr. Thomas Clark',
    departmentId: 'radiology',
    departmentName: 'Radiology',
    experience: 13,
    education: 'MD, FRCR',
    availability: ['Tuesday', 'Thursday', 'Saturday'],
    initials: 'TC'
  },
  // Emergency Medicine
  {
    id: 'dr-sanjay-chavan',
    name: 'Dr. Sanjay Chavan',
    departmentId: 'emergency-medicine',
    departmentName: 'Emergency Medicine',
    experience: 12,
    education: 'MD (Emergency Medicine)',
    availability: ['Monday', 'Tuesday', 'Thursday', 'Saturday'],
    initials: 'SC'
  },
  {
    id: 'dr-nancy-martinez',
    name: 'Dr. Nancy Martinez',
    departmentId: 'emergency-medicine',
    departmentName: 'Emergency Medicine',
    experience: 8,
    education: 'MD (Trauma & Critical Care)',
    availability: ['Wednesday', 'Thursday', 'Friday', 'Sunday'],
    initials: 'NM'
  }
];
