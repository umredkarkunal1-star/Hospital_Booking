import { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: 'b1',
    title: '10 Essential Heart Health Tips for Everyday Routine',
    category: 'Heart Health',
    excerpt: 'Simple yet impactful daily cardiovascular changes. Learn how brief brisk walking sessions, mindful fat selection, and salt reduction collectively improve cardiac longevity.',
    date: 'June 1, 2026'
  },
  {
    id: 'b2',
    title: 'Understanding Diabetes: Early Warning Signs & Prevention',
    category: 'Endocrinology',
    excerpt: 'Explore the subtle symptoms of insulin resistance and type-2 diabetes mellitus, and discover clinical-grade dietary strategies to naturally stabilize your average HbA1c levels.',
    date: 'May 28, 2026'
  },
  {
    id: 'b3',
    title: 'Why a Simple Annual Preventive Health Checkup Saves Lives',
    category: 'Preventive Care',
    excerpt: 'Regular biochemistry screenings and physical scans detect underlying renal, hepatic, or cardiac conditions before symptoms emerge. Early diagnostics remain your strongest protection.',
    date: 'May 15, 2026'
  }
];
