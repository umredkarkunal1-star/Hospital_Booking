import { Department } from '../types';

export const departments: Department[] = [
  {
    id: 'cardiology',
    name: 'Cardiology',
    description: 'State-of-the-art heart care focusing on advanced cardiovascular diagnostics and treatments.',
    iconName: 'Heart'
  },
  {
    id: 'neurology',
    name: 'Neurology',
    description: 'Expert evaluation and management of disorders affecting the brain and nervous system.',
    iconName: 'Brain'
  },
  {
    id: 'orthopedics',
    name: 'Orthopedics',
    description: 'Comprehensive surgical and non-surgical treatments for joint and bone conditions.',
    iconName: 'Activity'
  },
  {
    id: 'pediatrics',
    name: 'Pediatrics',
    description: 'Gentle and compassionate healthcare crafted specifically for infants, children, and teens.',
    iconName: 'Baby'
  },
  {
    id: 'oncology',
    name: 'Oncology',
    description: 'Multidisciplinary cancer care employing advanced molecular diagnostics and therapies.',
    iconName: 'Shield'
  },
  {
    id: 'dermatology',
    name: 'Dermatology',
    description: 'Advanced medical and cosmetic skin therapies delivered by certified specialists.',
    iconName: 'Sparkles'
  },
  {
    id: 'gynecology',
    name: 'Gynecology',
    description: 'Comprehensive women\'s wellness, prenatal management, and gynecological surgeries.',
    iconName: 'Users'
  },
  {
    id: 'ophthalmology',
    name: 'Ophthalmology',
    description: 'Precision vision care, advanced diagnostics, and microsurgical eye treatments.',
    iconName: 'Eye'
  },
  {
    id: 'ent',
    name: 'ENT',
    description: 'Specialized care for ear, nose, throat, head, and neck complications.',
    iconName: 'Volume2'
  },
  {
    id: 'gastroenterology',
    name: 'Gastroenterology',
    description: 'Comprehensive digestive wellness and state-of-the-art endoscopic evaluations.',
    iconName: 'Database'
  },
  {
    id: 'pulmonology',
    name: 'Pulmonology',
    description: 'Expert therapeutic and diagnostic management of chronic and acute lung conditions.',
    iconName: 'Wind'
  },
  {
    id: 'urology',
    name: 'Urology',
    description: 'Advanced care for urinary tract conditions and male reproductive health.',
    iconName: 'Flame'
  },
  {
    id: 'psychiatry',
    name: 'Psychiatry',
    description: 'Compassionate mental health evaluation, counseling, and psychiatric therapies.',
    iconName: 'Smile'
  },
  {
    id: 'radiology',
    name: 'Radiology',
    description: 'State-of-the-art imaging technologies including high-resolution MRI, CT, and X-ray.',
    iconName: 'Sun'
  },
  {
    id: 'emergency-medicine',
    name: 'Emergency Medicine',
    description: '24/7 life-saving emergency medical interventions and critical trauma management.',
    iconName: 'Ambulance'
  }
];
