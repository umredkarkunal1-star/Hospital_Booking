import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    name: 'Rajesh Solanki',
    rating: 5,
    quote: 'The cardiology team at We Care Hospital saved my life. Dr. Priya Sharma performed my angioplasty with absolute precision, and the post-operative attention I received in the ICU was incredibly detailed and reassuring.',
    treatment: 'Angioplasty & Cardiac Recovery'
  },
  {
    id: 't2',
    name: 'Meera Deshpande',
    rating: 5,
    quote: 'My daughter was admitted to the pediatrics ward with a severe respiratory issue. Dr. Nilesh Mehta and the entire pediatric nursing staff went above and beyond to keep her calm and comfortable. I will forever be grateful.',
    treatment: 'Pediatric Pulmonology Care'
  },
  {
    id: 't3',
    name: 'Vikram Sengupta',
    rating: 5,
    quote: 'After dealing with chronic knee pain for five years, I chose to undergo knee replacement surgery here. The orthopedics team under Dr. Amit Patil was stellar, and the physical therapy team got me back on my feet in record time.',
    treatment: 'Total Knee Replacement'
  },
  {
    id: 't4',
    name: 'Harish Nair',
    rating: 5,
    quote: 'The diagnostic speed here is phenomenal. I came to the emergency room with severe abdominal pain and was diagnosed with appendicitis, operated on, and placed in recovery within three hours. Truly world-class health operations.',
    treatment: 'Emergency Appendectomy'
  },
  {
    id: 't5',
    name: 'Kiran Gokhale',
    rating: 5,
    quote: 'Dr. Sneha Reddy treated my stubborn skin condition which had been misdiagnosed elsewhere. She spent a solid 30 minutes explaining the root cause and prescribing a simple, effective topical regimen. Highly intellectual dermatologist.',
    treatment: 'Advanced Dermatological Therapy'
  },
  {
    id: 't6',
    name: 'Anjali Shah',
    rating: 5,
    quote: 'Excellent prenatal care and delivery experience. The gynecology and labor ward team is warm, welcoming, and exceptionally skilled. They made my first pregnancy and delivery journey completely stress-free.',
    treatment: 'Maternity & Normal Delivery'
  }
];
