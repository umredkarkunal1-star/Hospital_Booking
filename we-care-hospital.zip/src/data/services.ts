import { Service } from '../types';

export const services: Service[] = [
  {
    id: 'emergency-care',
    title: 'Emergency Care (24/7)',
    description: 'Round-the-clock emergency medical response with trauma specialists, cardiac alert systems, and fast triage.',
    iconName: 'ShieldAlert'
  },
  {
    id: 'diagnostic-imaging',
    title: 'Diagnostic Imaging',
    description: 'Advanced resolution MRI, multi-slice CT scans, high-frequency ultrasound, and digital X-ray services.',
    iconName: 'Eye'
  },
  {
    id: 'pathology-lab-tests',
    title: 'Pathology & Lab Tests',
    description: 'Fully automated diagnostic laboratory performing hematology, biochemistry, molecular biology, and histopathology.',
    iconName: 'ClipboardList'
  },
  {
    id: 'surgery-operation-theatre',
    title: 'Surgery & Operation Theatre',
    description: 'Ultra-clean specialized surgical theatres equipped for minimally invasive laparoscopic and open-heart surgical procedures.',
    iconName: 'Activity'
  },
  {
    id: 'icu-critical-care',
    title: 'ICU & Critical Care',
    description: 'Continuous high-dependency life support monitoring systems overseen 24/7 by dedicated intensive care doctors.',
    iconName: 'HeartPulse'
  },
  {
    id: 'preventive-health-checkups',
    title: 'Preventive Health Checkups',
    description: 'Tailored health packages designed to assess general, corporate, cardiovascular, and metabolic well-being early.',
    iconName: 'CheckSquare'
  },
  {
    id: 'telemedicine-consultations',
    title: 'Telemedicine Consultations',
    description: 'Secure and confidential video consultations with senior specialist physicians from the comfort of your home.',
    iconName: 'Video'
  },
  {
    id: 'pharmacy-services',
    title: 'Pharmacy Services',
    description: '24-hour stocked hospital pharmacy providing authentic medications, medical consumables, and clinical support.',
    iconName: 'Pill'
  },
  {
    id: 'physiotherapy-rehabilitation',
    title: 'Physiotherapy & Rehab',
    description: 'Comprehensive physical therapy programs for post-surgical recovery, spinal care, and motor skill restoration.',
    iconName: 'Accessibility'
  },
  {
    id: 'ambulance-services',
    title: 'Ambulance Services',
    description: 'Advanced life-support ambulances equipped with transport ventilators, defibrillators, and direct hospital telemetry.',
    iconName: 'Ambulance'
  },
  {
    id: 'blood-bank',
    title: 'Blood Bank',
    description: 'Licensed blood component storage facility offering round-the-clock cross-matching and component separation (packed cells, plasma).',
    iconName: 'Droplet'
  },
  {
    id: 'vaccination-immunization',
    title: 'Vaccination & Immunization',
    description: 'Full pediatric, adult, and travel vaccination programs following global WHO and international health guidelines.',
    iconName: 'Syringe'
  }
];
