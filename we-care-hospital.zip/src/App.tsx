import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { EmergencyBanner } from './components/EmergencyBanner';
import { Footer } from './components/Footer';

import { Home } from './pages/Home';
import { DepartmentsPage } from './pages/DepartmentsPage';
import { DoctorsPage } from './pages/DoctorsPage';
import { ServicesPage } from './pages/ServicesPage';
import { BookingPage } from './pages/BookingPage';
import { ContactPage } from './pages/ContactPage';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-white flex flex-col justify-between text-gray-800">
        <div className="flex-1">
          {/* Prominent Emergency Banner */}
          <EmergencyBanner />
          
          {/* Sticky responsive Navbar */}
          <Navbar />
          
          {/* Central Client Route Outlets */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/departments" element={<DepartmentsPage />} />
            <Route path="/doctors" element={<DoctorsPage />} />
            <Route path="/doctors/:departmentId" element={<DoctorsPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/book-appointment" element={<BookingPage />} />
            <Route path="/contact" element={<ContactPage />} />
            {/* Safe redirect fallback to home on unknown routes */}
            <Route path="*" element={<Home />} />
          </Routes>
        </div>
        
        {/* Clinical Brand Footer Info */}
        <Footer />
      </div>
    </BrowserRouter>
  );
}
